import pens from "../assets/img/pens.svg"

export default function Button() {
  return (
    <button className="add">
        <img src={pens} alt=""></img>
    </button>
  )
}
