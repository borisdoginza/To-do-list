import edit from "../assets/img/pens.svg";
import del from "../assets/img/basket.svg";

export default function NotesItem( {note, view} ) {
  const {title, text, date } = note
  const topClass = view ? 'note__top between' : 'note__top';
  return (
    <div className="note">
      <div className={topClass}>
      <h3 className="h2 note__title">{title}</h3>

      
        <span className="note__date">{date}</span>
        
      </div>
      <p className="note__text">{text}</p>
      
      <div className="note__btns">

        <button className="note__btn edit btn"><img src={edit} alt=""/>РЕДАКТИРОВАТЬ</button>
        <button className="note__btn del btn"><img src={del} alt=""/>Удалить</button>

      </div>
    </div>
  )
}

