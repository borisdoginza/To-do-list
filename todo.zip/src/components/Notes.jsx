import { useState } from "react";
import grid from "../assets/img/layout.svg";
import list from "../assets/img/list.svg";
import NotesItem from "./NotesItem";

export default function Notes({ notes }) {

  const [view, setView] = useState(false)

  let btnIcon = view ? grid : list;
  let btnText = view ? 'Сетка' : 'Список';
  const itemsClass = view ? 'notes__items list' : 'notes__items';

  const changeView = () => setView(!view)

  return (
    <div className="notes">
      <div className="notes__top container">
        <h2 className="notes__title">Все заметки</h2>
        <button className="notes__btn" onClick={changeView}><img src={btnIcon} alt="" /><span>{btnText}</span></button>
      </div>

      <div className={`${itemsClass} container`}>
        {notes.map((note) => (
          <NotesItem note={note} key={note.id} view={view}/>
          ))}
      </div>
    </div>
  )
}
