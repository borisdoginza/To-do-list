import search from "../assets/img/search.svg";

export default function Navbar() {
  return (
    <nav className="nav">
      <button className="nav__lang">Ru</button>
      <h1 className="nav__title">Заметки</h1>
      <button className="nav__search">
        <img src={search} alt="Поиск" />
      </button>
    </nav>
  );
}
