

export default function Modal() {
  return (
    <div className="modal">
      <div className="modal__block">
        <h3 className="modal__title">Добавить заметку</h3>
        <div className="modal__inputs">
          <label className="modal__label">
            <input type="text" placeholder="Title" />
            <span>Title</span>
          </label>
          <label className="modal__label">
            <input type="text" placeholder="Content" />
            <span>Content</span >
          </label>
        </div>

        <div className="modal__btns">
          <button className="madal__btn del btn">Отмена</button>
          <button className="madal__btn edit btn">Добавить</button>
        </div>
      </div>
    </div>
  );
}
