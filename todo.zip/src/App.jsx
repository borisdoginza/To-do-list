import { useState } from "react";
import Navbar from "./components/Navbar";
import Notes from "./components/Notes";
import Button from "./components/Button";
import Modal from "./components/Modal";

export default function App(){

  const [notes, setNotes] = useState(
    [
      {
        id:crypto.randomUUID(),
        title: 'Первая заметка',
        text:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum qui, natus perspiciatis',
        date: new Date().toLocaleString()
      },

      {
        id:crypto.randomUUID(),
        title: 'Вторая заметка',
        text:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum qui, natus perspiciatis',
        date: new Date().toLocaleString()
      },

      {
        id:crypto.randomUUID(),
        title: 'Третья заметка',
        text:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum qui, natus perspiciatis',
        date: new Date().toLocaleString()
      }
    ]
  )

  return (
    <>
      <Navbar />
      <Notes notes={notes}/>
      <Button/>
      <Modal/>
    </>
  )
}